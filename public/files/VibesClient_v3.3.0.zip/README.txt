﻿Vibes Client v3.3.0 Beta
=======================

УСТАНОВКА:
1. Распакуйте архив в любую папку (например, C:\Vibes\).
2. Запустите VibesLauncher.exe от имени администратора.
3. Нажмите "Inject Only".
4. В игре нажмите Right Shift, чтобы открыть меню.

ТРЕБОВАНИЯ:
- Windows 10/11
- Minecraft Bedrock Edition (Microsoft Store)
- Запуск от имени администратора

ФАЙЛЫ:
- VibesLauncher.exe — лаунчер для инжекта
- DirectX12-Example-ImGui.dll — сам клиент
- Configs\ — папка с настройками (создастся автоматически)

ХОТКЕИ:
- Right Shift / Right Ctrl / Insert / F1 — открыть меню
- F2 — скрыть/показать HUD

Приятной игры!
